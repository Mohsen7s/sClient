P=mingw64 C=-DZLIB_DLL L="-s -static-libgcc" D=z.dll A=z.a ./build.sh
