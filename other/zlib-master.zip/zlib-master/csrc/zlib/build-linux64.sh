P=linux64 C="-fPIC -include _memcpy.h -DHAVE_UNISTD_H" L="-s -static-libgcc" D=libz.so A=libz.a ./build.sh
