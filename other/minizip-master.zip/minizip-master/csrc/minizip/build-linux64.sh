P=linux64 C="-fPIC -include _memcpy.h" L="-s -static-libgcc" D=libminizip.so A=libminizip.a ./build.sh
