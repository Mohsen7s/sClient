P=mingw64 C=iowin32.c L="-s -static-libgcc" D=minizip.dll A=minizip.a ./build.sh
